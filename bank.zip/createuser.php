<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" type="text/css" href="css/style.css">



    <!--===============================================================================================-->  
  <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

</head>
  


<body>

<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.php">SIOB Bank<span>.</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li class="active"><a href="createuser.php">Create User</a></li>
          <li><a href="transfermoney.php">Transfer Money</a></li>
          <li><a href="transactionhistory.php">Transaction History</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>


<?php
    include 'config.php';
    if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $balance=$_POST['balance'];
    $sql="insert into users(name,email,balance) values('{$name}','{$email}','{$balance}')";
    $result=mysqli_query($conn,$sql);
    if($result){
               echo "<script> alert('Hurray! User created');
                               window.location='transfermoney.php';
                     </script>";
                    
    }
  }
?>



<div class="limiter" style="position: absolute; top: 70px;">
    <div class="container-login100" style="background-image: url('images/bg-01.jpg');">
      <div class="wrap-login100">
        <form class="login100-form validate-form app-form" method="post">
          <span class="login100-form-logo">
            <i class="zmdi zmdi-account-circle"></i>
          </span>

          <span class="login100-form-title p-b-34 p-t-27">
            Create a User
          </span>

          <div class="wrap-input100 validate-input app-form-group" data-validate = "Enter name">
            <input class="input100" type="text" name="name" placeholder="Name">
            <span class="focus-input100" data-placeholder="&#xf207;"></span>
          </div>

          <div class="wrap-input100 validate-input app-form-group" data-validate="Enter email">
            <input class="input100" type="email" name="email" placeholder="Email">
            <span class="focus-input100" data-placeholder="&#xf159;"></span>
          </div>

          <div class="wrap-input100 validate-input app-form-group" data-validate="Enter balance">
            <input class="input100" type="number" name="balance" placeholder="Balance">
            <span class="focus-input100" data-placeholder="&#xf112;"></span>
          </div>

          <div class="container-login100-form-btn">
            <button class="login100-form-btn" style="right: 15px;" class="app-form-button" type="submit" value="CREATE" name="submit">
              Create
            </button>
            <button class="login100-form-btn app-form-button" style="left: 15px;" type="reset" value="RESET" name="reset">Reset</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>
</html>