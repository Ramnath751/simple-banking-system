<?php

	$conn = mysqli_connect('sql111.epizy.com','epiz_27735235','QijUq6yLW9yoYYi','epiz_27735235_bank');

	if(!$conn){
		die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
	}

?>