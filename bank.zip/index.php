<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--===============================================================================================-->  
  <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Do+Hyeon&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/navbar.css">

    <title>Basic Banking System</title>
  </head>

  <body>
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.php">SIOB Bank<span>.</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="createuser.php">Create User</a></li>
          <li><a href="transfermoney.php">Transfer Money</a></li>
          <li><a href="transactionhistory.php">Transaction History</a></li>
        </ul>
      </nav>

    </div>
  </header>
      <!-- Introduction section -->
            <div class="row py-1 no-gutters" style="position: absolute; top: 90px;">
              <div class="col-sm-12 col-md no no-gutters" style="top: 50px; left: 40px;">
                <div class="heading text-center my-5 no-gutters" style="font-family: 'Acme', sans-serif;">
                  <h3>Welcome to</h3>
                  <h1>SIOB BANK</h1>
                </div>
              </div>
              <div class="col-sm-12 col-md img text-center no-gutters" style="top: 12px;">
                <img src="img/banklogo.png" class="pt-2" style="width: 40%; height: 100%;">
              </div>
            </div>

      <!-- Activity section -->
            <div class="row activity text-center no-gutters">
                  <div class="col-md act p-4" style="top: 360px;">
                    <img src="img/user.jpg" class="img-fluid" style="border-radius: 100%">
                    <br>
                    <a href="createuser.php"><button class="btn btn-primary btn-sm">Create a User</button></a>
                  </div>
                  <div class="col-md act p-4" style="top: 360px;">
                    <img src="img/transfer.jpg" class="img-fluid" style="border-radius: 100%">
                    <br>
                    <a href="transfermoney.php"><button class="btn btn-primary btn-sm">Make a Transaction</button></a>
                  </div>
                  <div class="col-md act p-4" style="top: 360px;">
                    <img src="img/history.jpg" class="img-fluid" style="border-radius: 100%">
                    <br>
                    <a href="transactionhistory.php"><button class="btn btn-primary btn-sm">Transaction History</button></a>
                  </div>
            </div>
      </div>
    </body>
      <!-- <footer class="text-center p-4">
        <p>Made by <b>RAMNATH</b>
      </footer> -->
</html>